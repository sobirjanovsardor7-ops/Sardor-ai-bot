import os
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
from google import genai

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

TELEGRAM_BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]

client = genai.Client(api_key=GEMINI_API_KEY)
MODEL = "gemini-3.8-flash"

SYSTEM_PROMPT = (
    "You are SARDOR AI, a helpful Telegram assistant. "
    "Reply clearly and naturally. You can answer in Uzbek, Russian, or English "
    "and should normally match the user's language."
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Salom! 👋 Men SARDOR AI.\n"
        "Menga istalgan savolingizni yozing."
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 SARDOR AI\n\n"
        "Savolingizni oddiy xabar qilib yuboring — men javob beraman."
    )

async def ai_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return

    user_text = update.message.text.strip()
    if not user_text:
        return

    try:
        await update.message.chat.send_action("typing")

        prompt = f"{SYSTEM_PROMPT}\n\nUser message:\n{user_text}"
        response = client.models.generate_content(
            model=MODEL,
            contents=prompt,
        )

        answer = (response.text or "").strip()
        if not answer:
            answer = "Kechirasiz, javob hosil bo‘lmadi."

        # Telegram messages have a length limit; split long answers.
        for i in range(0, len(answer), 4000):
            await update.message.reply_text(answer[i:i + 4000])

    except Exception as e:
        logging.exception("AI error")
        await update.message.reply_text(
            "❌ AI bilan ulanishda xatolik yuz berdi.\n"
            "Keyinroq yana urinib ko‘ring."
        )

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logging.exception("Telegram error", exc_info=context.error)

def main():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, ai_reply))
    app.add_error_handler(error_handler)

    print("SARDOR AI bot ishga tushdi...")
    app.run_polling()

if __name__ == "__main__":
    main()
