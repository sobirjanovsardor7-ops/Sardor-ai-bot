# SARDOR AI — Telegram + Gemini

## 1. O'rnatish
Python 3.9+ kerak.

```bash
pip install -r requirements.txt
```

## 2. Environment variables
`TELEGRAM_BOT_TOKEN` — @BotFather bergan token.
`GEMINI_API_KEY` — Google AI Studio API key.

Tokenlarni kodga yozmang va hech kimga yubormang.

## 3. Ishga tushirish

Linux/macOS:
```bash
export TELEGRAM_BOT_TOKEN="..."
export GEMINI_API_KEY="..."
python bot.py
```

Windows PowerShell:
```powershell
$env:TELEGRAM_BOT_TOKEN="..."
$env:GEMINI_API_KEY="..."
python bot.py
```

## 4. Telegram
Botga `/start` yuboring va oddiy savol yozing.
